package com.polites.android.example;

import android.os.Bundle;

public class ScaleTypeCenterCropPortrait extends ExampleActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.scale_type_crop_portrait);
    }
}